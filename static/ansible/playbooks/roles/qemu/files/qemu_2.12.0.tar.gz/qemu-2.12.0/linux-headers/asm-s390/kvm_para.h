/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/*
 * User API definitions for paravirtual devices on s390
 *
 * Copyright IBM Corp. 2008
 *
 *    Author(s): Christian Borntraeger <borntraeger@de.ibm.com>
 */
