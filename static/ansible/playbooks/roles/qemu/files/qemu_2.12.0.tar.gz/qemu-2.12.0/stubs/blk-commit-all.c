#include "qemu/osdep.h"
#include "qemu-common.h"
#include "sysemu/block-backend.h"

int blk_commit_all(void)
{
    return 0;
}
