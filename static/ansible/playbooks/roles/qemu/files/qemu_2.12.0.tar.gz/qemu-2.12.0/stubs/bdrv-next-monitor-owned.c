#include "qemu/osdep.h"
#include "qemu-common.h"
#include "block/block.h"

BlockDriverState *bdrv_next_monitor_owned(BlockDriverState *bs)
{
    return NULL;
}
