#include "qemu/osdep.h"
#include "hw/i386/pc.h"

void pc_madt_cpu_entry(AcpiDeviceIf *adev, int uid,
                       const CPUArchIdList *apic_ids, GArray *entry)
{
}
