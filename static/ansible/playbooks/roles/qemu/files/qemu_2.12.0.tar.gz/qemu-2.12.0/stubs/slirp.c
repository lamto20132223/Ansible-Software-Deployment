#include "qemu/osdep.h"
#include "qemu-common.h"
#include "qemu/host-utils.h"
#include "slirp/slirp.h"

void slirp_pollfds_fill(GArray *pollfds, uint32_t *timeout)
{
}

void slirp_pollfds_poll(GArray *pollfds, int select_error)
{
}

