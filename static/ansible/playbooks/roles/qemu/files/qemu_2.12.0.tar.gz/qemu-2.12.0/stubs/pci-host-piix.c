#include "qemu/osdep.h"
#include "hw/i386/pc.h"
PCIBus *find_i440fx(void)
{
    return NULL;
}
