#include "qemu/osdep.h"
#include "qemu-common.h"
#include "qemu/main-loop.h"

void qemu_notify_event(void)
{
}
