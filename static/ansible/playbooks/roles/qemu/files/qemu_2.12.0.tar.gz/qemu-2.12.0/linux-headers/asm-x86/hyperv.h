#include "standard-headers/asm-x86/hyperv.h"
